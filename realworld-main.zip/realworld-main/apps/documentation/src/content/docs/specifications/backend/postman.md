---
title: Postman
---

For your convenience, we have a [Postman collection](https://github.com/gothinkster/realworld/blob/master/api/Conduit.postman_collection.json) that you can use to test your API endpoints as you build your app.

## Running API tests locally

To locally run the provided Postman collection against your backend, follow instructions [here](https://github.com/gothinkster/realworld/tree/main/api).
