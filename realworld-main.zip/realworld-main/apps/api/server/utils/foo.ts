export const useFoo = () => {
    console.log('done')
}
