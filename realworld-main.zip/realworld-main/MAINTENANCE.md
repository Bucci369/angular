## Update nx

```shell
npx nx migrate latest
```

### run migrations

```shell
npx nx migrate --run-migrations
```

## detect MDX2 errors for Storybook

run `npx @hipster/mdx2-issue-checker`
